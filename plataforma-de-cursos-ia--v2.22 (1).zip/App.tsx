
import React, { useState } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CourseCard } from './components/CourseCard';
import { AiCourseGenerator } from './components/AiCourseGenerator';
import { AuthModal } from './components/AuthModal';
import { CourseUpload } from './components/CourseUpload';
import { CourseDetailView } from './components/CourseDetailView';
import { SAMPLE_COURSES } from './constants';
import type { Course, GeneratedCoursePlan, User } from './types';

export default function App() {
  const [activeView, setActiveView] = useState<'courses' | 'generator' | 'upload'>('courses');
  const [courses, setCourses] = useState<Course[]>(SAMPLE_COURSES);
  const [generatedPlan, setGeneratedPlan] = useState<GeneratedCoursePlan | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'login' | 'register'>('login');
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  // This state will hold references to all uploaded files for the session,
  // preventing their blob URLs from becoming invalid after navigation.
  const [blobReferences, setBlobReferences] = useState<File[]>([]);


  const handlePlanGenerated = (plan: GeneratedCoursePlan) => {
    setGeneratedPlan(plan);
    setActiveView('generator');
  };

  const handleNavigation = (view: 'courses' | 'generator' | 'upload') => {
    if (view === 'generator' && !generatedPlan) {
      setGeneratedPlan(null);
    }
    setSelectedCourse(null); // Always go back to list view on main navigation
    setActiveView(view);
  };

  const handleAuthClick = (tab: 'login' | 'register') => {
    setAuthModalTab(tab);
    setIsAuthModalOpen(true);
  };

  const handleLoginSuccess = (userData: User) => {
    setUser(userData);
    setIsAuthModalOpen(false);
  };

  const handleLogout = () => {
    setUser(null);
    setSelectedCourse(null);
    setActiveView('courses'); // Redirect to home on logout
  };

  const handleCourseUploaded = (newCourse: Omit<Course, 'id'>, files: File[]) => {
    const courseWithId = {
      ...newCourse,
      id: courses.length + 1,
    };
    setCourses(prevCourses => [courseWithId, ...prevCourses]);
    // By storing the File objects in the top-level state, we ensure the blob URLs
    // created from them remain valid throughout the session.
    setBlobReferences(prevFiles => [...prevFiles, ...files]);
    setSelectedCourse(courseWithId); // Navigate to the new course's detail page
  };
  
  const handleSelectCourse = (course: Course) => {
    setSelectedCourse(course);
  };

  const handleBackToList = () => {
    setSelectedCourse(null);
  };


  return (
    <div className="flex flex-col min-h-screen bg-base-100 font-sans">
      <Header 
        activeView={activeView} 
        onNavigate={handleNavigation}
        user={user}
        onAuthClick={handleAuthClick}
        onLogout={handleLogout}
      />
      
      <main className="flex-grow container mx-auto px-4 py-8 md:py-12">
        {selectedCourse ? (
          <CourseDetailView course={selectedCourse} onBack={handleBackToList} />
        ) : (
          <>
            {activeView === 'courses' && (
              <div>
                <div className="text-center mb-12">
                  <h1 className="text-4xl md:text-5xl font-bold text-white">Explore Nossos Cursos</h1>
                  <p className="mt-4 text-lg text-text-muted max-w-2xl mx-auto">
                    Descubra uma variedade de cursos nas mais diversas áreas do conhecimento.
                  </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {courses.map((course: Course) => (
                    <CourseCard key={course.id} course={course} onSelectCourse={handleSelectCourse} />
                  ))}
                </div>
                <div className="text-center mt-16 p-8 bg-base-200 rounded-lg shadow-2xl border border-base-300">
                    <h2 className="text-3xl font-bold text-white">Não encontrou o que queria?</h2>
                    <p className="mt-4 text-text-muted">Use nossa IA para criar um plano de estudos personalizado para qualquer tópico!</p>
                    <button 
                      onClick={() => handleNavigation('generator')}
                      className="mt-6 bg-brand-primary hover:bg-teal-500 text-white font-bold py-3 px-6 rounded-lg transition-transform duration-300 ease-in-out transform hover:scale-105"
                    >
                      Criar Plano com IA
                    </button>
                </div>
              </div>
            )}

            {activeView === 'generator' && (
              <AiCourseGenerator 
                onPlanGenerated={handlePlanGenerated} 
                initialPlan={generatedPlan}
              />
            )}

            {activeView === 'upload' && user && (
                <CourseUpload onCourseUploaded={handleCourseUploaded} />
            )}
          </>
        )}
      </main>

      <Footer />

      {isAuthModalOpen && (
        <AuthModal 
          initialTab={authModalTab}
          onClose={() => setIsAuthModalOpen(false)}
          onLoginSuccess={handleLoginSuccess}
        />
      )}
    </div>
  );
}
