// For user-uploaded videos
export type LessonType = 'youtube' | 'audio' | 'image' | 'video';

export interface Lesson {
  title: string;
  type: LessonType;
  url: string;
}

// For user-uploaded courses
export interface CourseModule {
  title: string;
  lessons: Lesson[];
}

// For AI-generated plans
export interface AiCourseModule {
  title: string;
  lessons: string[];
}

export interface Course {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
  modules?: CourseModule[];
}

export interface GeneratedCoursePlan {
  title:string;
  description: string;
  modules: AiCourseModule[];
}

export interface User {
  name: string;
  email: string;
}