import type { Course } from './types';

export const SAMPLE_COURSES: Course[] = [
  {
    id: 1,
    title: 'React: Do Básico ao Avançado',
    description: 'Aprenda a construir aplicações web modernas e reativas com a biblioteca mais popular do mercado.',
    imageUrl: 'https://picsum.photos/seed/react/600/400',
    modules: [
      {
        title: 'Módulo 1: Introdução ao React',
        lessons: [
          { title: 'O que é React e por que usá-lo?', type: 'youtube', url: 'https://www.youtube.com/watch?v=s2skans2dP4' },
          { title: 'Demonstração: Componente de Vídeo Nativo', type: 'video', url: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' },
          { title: 'Infográfico: Configurando o Ambiente', type: 'image', url: 'https://picsum.photos/seed/react-setup/800/450' },
        ],
      },
      {
        title: 'Módulo 2: Componentes e Props',
        lessons: [
          { title: 'Componentes Funcionais vs. de Classe', type: 'youtube', url: 'https://www.youtube.com/watch?v=fd2hSHbKd-4' },
          { title: 'Podcast: Aprofundando em Props', type: 'audio', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3' },
          { title: 'Desestruturando Props', type: 'image', url: 'https://picsum.photos/seed/react-props/800/450' },
        ],
      },
    ],
  },
  {
    id: 2,
    title: 'Design de UI/UX para Desenvolvedores',
    description: 'Domine os princípios de design para criar interfaces bonitas, funcionais e amigáveis ao usuário.',
    imageUrl: 'https://picsum.photos/seed/design/600/400',
  },
  {
    id: 3,
    title: 'Marketing Digital Essencial',
    description: 'Descubra as estratégias e ferramentas para impulsionar negócios no ambiente digital.',
    imageUrl: 'https://picsum.photos/seed/marketing/600/400',
  },
   {
    id: 4,
    title: 'Introdução à Inteligência Artificial',
    description: 'Explore os conceitos fundamentais de IA e aprenda a aplicar modelos como o Gemini API.',
    imageUrl: 'https://picsum.photos/seed/ai/600/400',
  },
  {
    id: 5,
    title: 'Gestão Ágil de Projetos com Scrum',
    description: 'Aprenda a gerenciar projetos de forma eficiente e colaborativa com a metodologia Scrum.',
    imageUrl: 'https://picsum.photos/seed/scrum/600/400',
  },
  {
    id: 6,
    title: 'Fotografia para Iniciantes',
    description: 'Domine sua câmera e aprenda as técnicas para capturar fotos incríveis em qualquer situação.',
    imageUrl: 'https://picsum.photos/seed/photo/600/400',
  },
];