
import { GoogleGenAI, Type } from "@google/genai";
import type { GeneratedCoursePlan, AiCourseModule } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // In a real app, you might want to handle this more gracefully.
  // For this example, we'll throw an error to make it clear.
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const coursePlanSchema = {
    type: Type.OBJECT,
    properties: {
        title: { 
            type: Type.STRING, 
            description: "Um título criativo e conciso para o curso em português." 
        },
        description: { 
            type: Type.STRING, 
            description: "Uma descrição curta e envolvente do curso (2-3 frases) em português." 
        },
        modules: {
            type: Type.ARRAY,
            description: "Uma lista de módulos para o curso. Cada módulo deve ter um título e uma lista de lições.",
            items: {
                type: Type.OBJECT,
                properties: {
                    title: { 
                        type: Type.STRING, 
                        description: "O título do módulo em português."
                    },
                    lessons: {
                        type: Type.ARRAY,
                        description: "Uma lista de lições para este módulo. Cada lição deve ser um tópico específico.",
                        items: { 
                            type: Type.STRING,
                            description: "O nome de uma lição específica em português." 
                        }
                    }
                },
                required: ["title", "lessons"]
            }
        }
    },
    required: ["title", "description", "modules"]
};

export async function generateCoursePlanWithGemini(topic: string): Promise<GeneratedCoursePlan> {
  const prompt = `Crie um plano de curso detalhado para o seguinte tópico: "${topic}". O plano deve ser bem estruturado, começando com conceitos básicos e progredindo para tópicos mais avançados. Gere uma resposta em português do Brasil.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: coursePlanSchema,
        temperature: 0.7,
      },
    });

    const jsonText = response.text.trim();
    const courseData = JSON.parse(jsonText) as GeneratedCoursePlan;
    
    // Basic validation to ensure the structure is correct
    if (!courseData.title || !courseData.description || !Array.isArray(courseData.modules)) {
        throw new Error("Resposta da API em formato inesperado.");
    }
    
    return courseData;
  } catch (error) {
    console.error("Erro ao chamar a Gemini API:", error);
    // You could re-throw a more user-friendly error or handle it as needed
    throw new Error("Falha na comunicação com o serviço de IA. Por favor, tente novamente.");
  }
}
