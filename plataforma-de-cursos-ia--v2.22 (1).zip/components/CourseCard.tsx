
import React from 'react';
import type { Course } from '../types';

interface CourseCardProps {
  course: Course;
  onSelectCourse: (course: Course) => void;
}

export const CourseCard: React.FC<CourseCardProps> = ({ course, onSelectCourse }) => {
  return (
    <div className="bg-base-200 rounded-lg overflow-hidden shadow-lg hover:shadow-brand-primary/20 hover:-translate-y-1 transition-all duration-300 flex flex-col">
      <img className="w-full h-48 object-cover" src={course.imageUrl} alt={course.title} />
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-xl font-bold text-white mb-2">{course.title}</h3>
        <p className="text-text-muted text-sm flex-grow mb-4">{course.description}</p>
        <button 
          onClick={() => onSelectCourse(course)}
          className="mt-auto w-full bg-brand-primary hover:bg-teal-500 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-300"
        >
          Saber Mais
        </button>
      </div>
    </div>
  );
};
