import React from 'react';
import type { Course, Lesson } from '../types';

interface CourseDetailViewProps {
    course: Course;
    onBack: () => void;
}

const getYoutubeEmbedUrl = (url: string) => {
    let videoId = '';
    try {
        const urlObj = new URL(url);
        if (urlObj.hostname === 'youtu.be') {
            videoId = urlObj.pathname.slice(1);
        } else if (urlObj.hostname.includes('youtube.com')) {
            videoId = urlObj.searchParams.get('v') || '';
        }
    } catch(e) {
        console.error("Invalid URL for YouTube embed", e);
    }
    if (videoId) {
        return `https://www.youtube.com/embed/${videoId}`;
    }
    return ''; // Return empty string or some fallback if URL is not a valid YouTube URL
};

const LessonContent: React.FC<{ lesson: Lesson }> = ({ lesson }) => {
    switch (lesson.type) {
        case 'youtube':
            const embedUrl = getYoutubeEmbedUrl(lesson.url);
            if (!embedUrl) {
                return <p className="text-red-400">URL do YouTube inválida.</p>;
            }
            return (
                <div className="aspect-w-16 aspect-h-9 bg-base-100 rounded-md overflow-hidden">
                    <iframe
                        src={embedUrl}
                        title={lesson.title}
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        className="w-full h-full"
                    ></iframe>
                </div>
            );
        case 'video':
             return (
                <div className="aspect-w-16 aspect-h-9 bg-base-100 rounded-md overflow-hidden">
                    <video
                        controls
                        src={lesson.url}
                        title={lesson.title}
                        className="w-full h-full"
                    >
                        Seu navegador não suporta o elemento de vídeo.
                    </video>
                </div>
            );
        case 'audio':
            return (
                 <audio controls className="w-full" src={lesson.url}>
                    Seu navegador não suporta o elemento de áudio.
                </audio>
            );
        case 'image':
            return (
                <img src={lesson.url} alt={lesson.title} className="w-full h-auto rounded-md bg-base-100" />
            );
        default:
            return <p className="text-text-muted">Tipo de conteúdo não suportado.</p>;
    }
};

export const CourseDetailView: React.FC<CourseDetailViewProps> = ({ course, onBack }) => {
    // A mapping for lesson type icons
    const lessonIcons: { [key in Lesson['type']]: React.ReactNode } = {
        youtube: (
             <svg className="w-6 h-6 mr-3 text-red-500 flex-shrink-0" fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"></path></svg>
        ),
        video: (
            <svg className="w-6 h-6 mr-3 text-orange-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>
        ),
        audio: (
            <svg className="w-6 h-6 mr-3 text-sky-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2z"></path></svg>
        ),
        image: (
            <svg className="w-6 h-6 mr-3 text-green-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
        ),
    };


    return (
        <div className="max-w-5xl mx-auto animate-fade-in">
            <button
                onClick={onBack}
                className="mb-8 inline-flex items-center text-text-muted hover:text-white transition-colors duration-300"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M9.707 14.707a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 1.414L7.414 9H15a1 1 0 110 2H7.414l2.293 2.293a1 1 0 010 1.414z" clipRule="evenodd" />
                </svg>
                Voltar para a lista de cursos
            </button>

            <div className="bg-base-200 rounded-lg shadow-2xl overflow-hidden border border-base-300">
                <img className="w-full h-64 md:h-80 object-cover" src={course.imageUrl} alt={course.title} />
                <div className="p-6 md:p-10">
                    <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">{course.title}</h1>
                    <p className="text-text-muted text-lg mb-8">{course.description}</p>
                    
                    <h2 className="text-2xl font-semibold text-white mb-6 border-b-2 border-brand-primary pb-2">Conteúdo do Curso</h2>

                    <div className="space-y-8">
                        {course.modules && course.modules.length > 0 ? (
                            course.modules.map((module, modIndex) => (
                                <div key={modIndex}>
                                    <h3 className="text-xl font-bold text-brand-primary mb-4">Módulo {modIndex + 1}: {module.title}</h3>
                                    <div className="space-y-6">
                                        {module.lessons.map((lesson, lessonIndex) => (
                                            <div key={lessonIndex} className="bg-base-300 p-4 rounded-lg">
                                                <div className="flex items-center font-semibold text-white mb-3">
                                                    {lessonIcons[lesson.type]}
                                                    <p>{lessonIndex + 1}. {lesson.title}</p>
                                                </div>
                                                <LessonContent lesson={lesson} />
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ))
                        ) : (
                            <p className="text-text-muted">Nenhum módulo ou aula foi adicionado a este curso ainda.</p>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};