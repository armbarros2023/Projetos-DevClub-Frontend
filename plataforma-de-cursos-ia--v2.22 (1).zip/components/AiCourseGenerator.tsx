
import React, { useState } from 'react';
import type { GeneratedCoursePlan } from '../types';
import { generateCoursePlanWithGemini } from '../services/geminiService';
import { GeneratedCoursePlanView } from './GeneratedCoursePlanView';

interface AiCourseGeneratorProps {
  onPlanGenerated: (plan: GeneratedCoursePlan) => void;
  initialPlan: GeneratedCoursePlan | null;
}

const LoadingSpinner = () => (
  <div className="flex flex-col items-center justify-center text-center space-y-4 p-8">
    <svg className="animate-spin h-12 w-12 text-brand-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
    <h3 className="text-xl font-semibold text-white">Gerando seu plano de estudos...</h3>
    <p className="text-text-muted">Aguarde um momento, a IA está criando algo incrível para você!</p>
  </div>
);

export const AiCourseGenerator: React.FC<AiCourseGeneratorProps> = ({ onPlanGenerated, initialPlan }) => {
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedPlan, setGeneratedPlan] = useState<GeneratedCoursePlan | null>(initialPlan);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) {
      setError('Por favor, insira um tópico.');
      return;
    }
    
    setLoading(true);
    setError(null);
    setGeneratedPlan(null);

    try {
      const plan = await generateCoursePlanWithGemini(topic);
      setGeneratedPlan(plan);
      onPlanGenerated(plan);
    } catch (err) {
      setError('Ocorreu um erro ao gerar o plano. Tente novamente mais tarde.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  const handleNewSearch = () => {
      setGeneratedPlan(null);
      setTopic('');
      setError(null);
  }

  if (loading) {
    return <LoadingSpinner />;
  }

  if (generatedPlan) {
    return <GeneratedCoursePlanView plan={generatedPlan} onNewSearch={handleNewSearch} />;
  }

  return (
    <div className="max-w-3xl mx-auto text-center">
      <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Gerador de Plano de Curso com IA</h1>
      <p className="text-lg text-text-muted mb-8">
        Tem uma ideia para um curso? Descreva o tópico e nossa IA criará um plano de estudos estruturado para você em segundos.
      </p>

      <form onSubmit={handleSubmit} className="bg-base-200 p-8 rounded-lg shadow-2xl border border-base-300">
        <div className="flex flex-col md:flex-row gap-4">
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="Ex: Introdução à culinária japonesa"
            className="flex-grow bg-base-300 text-white placeholder-text-muted px-4 py-3 rounded-lg border-2 border-transparent focus:border-brand-primary focus:outline-none focus:ring-0 transition-colors"
            disabled={loading}
          />
          <button
            type="submit"
            disabled={loading}
            className="bg-brand-primary hover:bg-teal-500 text-white font-bold py-3 px-8 rounded-lg transition-transform duration-300 ease-in-out transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Gerar Plano
          </button>
        </div>
        {error && <p className="text-red-400 mt-4">{error}</p>}
      </form>
    </div>
  );
};
