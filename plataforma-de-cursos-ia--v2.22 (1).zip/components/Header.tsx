
import React from 'react';
import type { User } from '../types';

const Logo = () => (
    <div className="flex items-center space-x-2">
        <svg className="w-8 h-8 text-brand-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v11.494m-9-5.747h18M5.468 18.37A9 9 0 1018.532 5.63a9.003 9.003 0 00-13.064 12.74z"></path>
        </svg>
        <span className="text-xl font-bold text-white">Cursos IA</span>
    </div>
);

interface NavLinkProps {
    label: string;
    isActive: boolean;
    onClick: () => void;
}

const NavLink: React.FC<NavLinkProps> = ({ label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-300 ${
            isActive 
            ? 'bg-brand-primary text-white' 
            : 'text-text-muted hover:text-white hover:bg-base-300'
        }`}
    >
        {label}
    </button>
);

interface HeaderProps {
    activeView: 'courses' | 'generator' | 'upload';
    onNavigate: (view: 'courses' | 'generator' | 'upload') => void;
    user: User | null;
    onAuthClick: (tab: 'login' | 'register') => void;
    onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ activeView, onNavigate, user, onAuthClick, onLogout }) => {
    return (
        <header className="sticky top-0 bg-base-200/80 backdrop-blur-lg shadow-md z-50">
            <div className="container mx-auto px-4">
                <div className="flex items-center justify-between h-16">
                    <div className="flex items-center space-x-4">
                        <Logo />
                        <nav className="hidden md:flex items-center space-x-4">
                            <NavLink 
                                label="Cursos" 
                                isActive={activeView === 'courses'} 
                                onClick={() => onNavigate('courses')}
                            />
                            <NavLink 
                                label="Gerador de Ideias" 
                                isActive={activeView === 'generator'} 
                                onClick={() => onNavigate('generator')}
                            />
                        </nav>
                    </div>
                    <div className="flex items-center space-x-4">
                        {user ? (
                            <>
                                <button
                                    onClick={() => onNavigate('upload')}
                                    className={`text-sm font-medium px-4 py-2 rounded-md transition-colors duration-300 ${activeView === 'upload' ? 'bg-brand-secondary text-white' : 'text-text-muted hover:text-white'}`}
                                >
                                    Publicar Curso
                                </button>
                                <span className="hidden sm:block text-text-muted">Olá, {user.name.split(' ')[0]}</span>
                                <button 
                                    onClick={onLogout}
                                    className="bg-red-600 hover:bg-red-500 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-300"
                                >
                                    Sair
                                </button>
                            </>
                        ) : (
                            <>
                                <button 
                                    onClick={() => onAuthClick('login')}
                                    className="hidden sm:block text-text-muted hover:text-white transition-colors duration-300 px-4 py-2"
                                >
                                    Login
                                </button>
                                <button 
                                    onClick={() => onAuthClick('register')}
                                    className="bg-brand-secondary hover:bg-indigo-600 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-300"
                                >
                                    Cadastro
                                </button>
                            </>
                        )}
                    </div>
                </div>
            </div>
        </header>
    );
};
