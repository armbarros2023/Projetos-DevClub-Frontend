
import React, { useState } from 'react';
import type { User } from '../types';

interface AuthModalProps {
  initialTab?: 'login' | 'register';
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
}

const GoogleIcon = () => (
    <svg className="w-5 h-5 mr-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
        <path d="M21.543 9.355h-1.82v-0.01a6.634 6.634 0 0 0-6.19-6.33 6.692 6.692 0 0 0-6.691 6.691 6.692 6.692 0 0 0 6.691 6.691 6.54 6.54 0 0 0 4.526-1.748l-2.07-2.069a3.732 3.732 0 0 1-2.456.867 3.792 3.792 0 0 1-3.792-3.791 3.792 3.792 0 0 1 3.792-3.792h.02a3.73 3.73 0 0 1 3.7 3.525v.266h-3.72v3.01h6.417a6.37 6.37 0 0 0 .233-2.345Z"/>
    </svg>
);


export const AuthModal: React.FC<AuthModalProps> = ({ initialTab = 'login', onClose, onLoginSuccess }) => {
  const [activeTab, setActiveTab] = useState(initialTab);
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', password: '' });
  const [error, setError] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  
  // Simulates a login/register action
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeTab === 'register' && !formData.name) {
        setError('O nome é obrigatório.');
        return;
    }
    if (!formData.email || !formData.password) {
        setError('Email e senha são obrigatórios.');
        return;
    }
    setError('');
    onLoginSuccess({ name: formData.name || 'Usuário', email: formData.email });
  };
  
  // Simulates Google Sign-In
  const handleGoogleSignIn = () => {
    onLoginSuccess({ name: 'Usuário Google', email: 'user@google.com' });
  };

  return (
    <div 
        className="fixed inset-0 bg-base-100/70 backdrop-blur-sm flex items-center justify-center z-[100] animate-fade-in"
        onClick={onClose}
        role="dialog"
        aria-modal="true"
    >
      <div 
        className="bg-base-200 rounded-lg shadow-2xl p-8 w-full max-w-md m-4 border border-base-300 relative"
        onClick={e => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-4 right-4 text-text-muted hover:text-white">&times;</button>
        
        <div className="flex border-b border-base-300 mb-6">
          <button 
            onClick={() => setActiveTab('login')}
            className={`flex-1 py-3 font-semibold text-center transition-colors duration-300 ${activeTab === 'login' ? 'text-brand-primary border-b-2 border-brand-primary' : 'text-text-muted hover:text-white'}`}
          >
            Login
          </button>
          <button 
            onClick={() => setActiveTab('register')}
            className={`flex-1 py-3 font-semibold text-center transition-colors duration-300 ${activeTab === 'register' ? 'text-brand-primary border-b-2 border-brand-primary' : 'text-text-muted hover:text-white'}`}
          >
            Cadastro
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="space-y-4">
            {activeTab === 'register' && (
              <input type="text" name="name" placeholder="Nome Completo" onChange={handleInputChange} className="w-full bg-base-300 text-white p-3 rounded-md border-2 border-transparent focus:border-brand-primary focus:outline-none"/>
            )}
            <input type="email" name="email" placeholder="Email" onChange={handleInputChange} className="w-full bg-base-300 text-white p-3 rounded-md border-2 border-transparent focus:border-brand-primary focus:outline-none"/>
            {activeTab === 'register' && (
              <input type="tel" name="phone" placeholder="Telefone (Opcional)" onChange={handleInputChange} className="w-full bg-base-300 text-white p-3 rounded-md border-2 border-transparent focus:border-brand-primary focus:outline-none"/>
            )}
            <input type="password" name="password" placeholder="Senha" onChange={handleInputChange} className="w-full bg-base-300 text-white p-3 rounded-md border-2 border-transparent focus:border-brand-primary focus:outline-none"/>
          </div>
          {error && <p className="text-red-400 text-sm mt-4 text-center">{error}</p>}
          <button type="submit" className="w-full mt-6 bg-brand-primary hover:bg-teal-500 text-white font-bold py-3 rounded-md transition-transform duration-300 transform hover:scale-105">
            {activeTab === 'login' ? 'Entrar' : 'Criar Conta'}
          </button>
        </form>

        <div className="flex items-center my-6">
            <hr className="flex-grow border-t border-base-300"/>
            <span className="mx-4 text-text-muted text-sm">OU</span>
            <hr className="flex-grow border-t border-base-300"/>
        </div>
        
        <button onClick={handleGoogleSignIn} className="w-full flex items-center justify-center bg-white text-gray-800 font-semibold py-3 rounded-md hover:bg-gray-200 transition-colors duration-300">
            <GoogleIcon />
            Entrar com Google
        </button>
      </div>
    </div>
  );
};
