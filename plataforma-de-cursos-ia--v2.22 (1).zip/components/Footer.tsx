
import React from 'react';

export const Footer = () => {
  return (
    <footer className="bg-base-200 border-t border-base-300 mt-12">
      <div className="container mx-auto px-4 py-6 text-center text-text-muted">
        <p>&copy; {new Date().getFullYear()} Plataforma de Cursos IA. Todos os direitos reservados.</p>
        <p className="text-sm mt-1">Potencializado com React e Gemini API</p>
      </div>
    </footer>
  );
};
