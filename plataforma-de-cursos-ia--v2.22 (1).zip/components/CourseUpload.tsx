
import React, { useState, useEffect } from 'react';
import type { Course, CourseModule, Lesson, LessonType } from '../types';

// Icons
const YoutubeIcon = () => (
    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"></path></svg>
);
const AudioIcon = () => (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2z"></path></svg>
);
const ImageIcon = () => (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
);
const VideoIcon = () => (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>
);
const AddIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
    </svg>
);
const TrashIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" />
    </svg>
);


interface CourseUploadProps {
    onCourseUploaded: (course: Omit<Course, 'id'>, files: File[]) => void;
}

type LessonState = { id: number; title: string; type: LessonType; url: string | null; file: File | null };
type ModuleState = { id: number; title: string; lessons: LessonState[] };

export const CourseUpload: React.FC<CourseUploadProps> = ({ onCourseUploaded }) => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [thumbnail, setThumbnail] = useState<File | null>(null);
    const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null);
    const [modules, setModules] = useState<ModuleState[]>([]);
    const [error, setError] = useState('');

    useEffect(() => {
        // Cleanup function to revoke object URLs when component unmounts
        return () => {
            if (thumbnailPreview) {
                URL.revokeObjectURL(thumbnailPreview);
            }
            modules.forEach(m => {
                m.lessons.forEach(l => {
                    if (l.url && l.file) {
                        URL.revokeObjectURL(l.url);
                    }
                });
            });
        };
    }, [thumbnailPreview, modules]);


    const handleThumbnailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setThumbnail(file);
            if (thumbnailPreview) {
                URL.revokeObjectURL(thumbnailPreview);
            }
            const previewUrl = URL.createObjectURL(file);
            setThumbnailPreview(previewUrl);
        }
    };

    const addModule = () => {
        setModules([...modules, { id: Date.now(), title: '', lessons: [] }]);
    };

    const removeModule = (moduleId: number) => {
        setModules(modules.filter(m => m.id !== moduleId));
    };

    const handleModuleChange = (moduleId: number, newTitle: string) => {
        setModules(modules.map(m => m.id === moduleId ? { ...m, title: newTitle } : m));
    };

    const addLesson = (moduleId: number, type: LessonType) => {
        setModules(modules.map(m => m.id === moduleId ? { ...m, lessons: [...m.lessons, { id: Date.now(), title: '', type, url: null, file: null }] } : m));
    };

    const removeLesson = (moduleId: number, lessonId: number) => {
        setModules(modules.map(m => {
            if (m.id === moduleId) {
                // Also clean up object URL
                const lessonToRemove = m.lessons.find(l => l.id === lessonId);
                if (lessonToRemove?.url && lessonToRemove?.file) {
                    URL.revokeObjectURL(lessonToRemove.url);
                }
                return { ...m, lessons: m.lessons.filter(l => l.id !== lessonId) };
            }
            return m;
        }));
    };

    const handleLessonChange = (moduleId: number, lessonId: number, field: 'title' | 'url' | 'file', value: string | File | null) => {
        setModules(modules.map(m => {
            if (m.id !== moduleId) return m;
            return {
                ...m,
                lessons: m.lessons.map(l => {
                    if (l.id !== lessonId) return l;
                    if (field === 'title') return { ...l, title: value as string };
                    if (field === 'url') return { ...l, url: value as string, file: null }; // for youtube link
                    if (field === 'file') {
                        const file = value as File | null;
                        if (l.url && l.file) { // if there was a file before, revoke its URL
                            URL.revokeObjectURL(l.url);
                        }
                        return { ...l, file: file, url: file ? URL.createObjectURL(file) : null };
                    }
                    return l;
                })
            };
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!title || !description || !thumbnail || modules.length === 0) {
            setError('Por favor, preencha todos os campos principais e adicione ao menos um módulo.');
            return;
        }

        const allFiles: File[] = [];
        if (thumbnail) {
            allFiles.push(thumbnail);
        }

        const formattedModules: CourseModule[] = [];
        for (const m of modules) {
            if (m.title.trim() === '') continue;

            const formattedLessons: Lesson[] = [];
            for (const l of m.lessons) {
                if (l.title.trim() === '' || !l.url) {
                     setError(`Todas as aulas devem ter um título e conteúdo (URL ou arquivo). Verifique a aula "${l.title || 'sem título'}" no módulo "${m.title}".`);
                     return;
                }
                if (l.file) {
                    allFiles.push(l.file);
                }
                formattedLessons.push({ title: l.title, type: l.type, url: l.url });
            }

            if(formattedLessons.length === 0){
                setError(`O módulo "${m.title}" deve ter pelo menos uma aula completa.`);
                return;
            }
            formattedModules.push({ title: m.title, lessons: formattedLessons });
        }
        
        if (formattedModules.length === 0) {
            setError('O curso deve ter pelo menos um módulo com título e aulas.');
            return;
        }
        
        const newCourseData = {
            title,
            description,
            imageUrl: thumbnailPreview!,
            modules: formattedModules
        };

        onCourseUploaded(newCourseData, allFiles);
    };

    const LessonInput = ({ lesson, modId }: { lesson: LessonState; modId: number; }) => {
        const commonFileClasses = "w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-brand-primary/80 file:text-white hover:file:bg-brand-primary";
        
        switch (lesson.type) {
            case 'youtube':
                return <input type="text" value={lesson.url || ''} onChange={e => handleLessonChange(modId, lesson.id, 'url', e.target.value)} placeholder="URL do vídeo no YouTube" className="w-full bg-base-100 text-white p-2 rounded-md border-2 border-transparent focus:border-brand-secondary/50 focus:outline-none"/>
            case 'video':
                return <input type="file" id={`video-${lesson.id}`} accept="video/*" onChange={e => handleLessonChange(modId, lesson.id, 'file', e.target.files?.[0] || null)} className={commonFileClasses}/>
            case 'audio':
                return <input type="file" id={`audio-${lesson.id}`} accept="audio/*" onChange={e => handleLessonChange(modId, lesson.id, 'file', e.target.files?.[0] || null)} className={commonFileClasses}/>
            case 'image':
                return <input type="file" id={`image-${lesson.id}`} accept="image/*" onChange={e => handleLessonChange(modId, lesson.id, 'file', e.target.files?.[0] || null)} className={commonFileClasses}/>
            default:
                return null;
        }
    };
    
    const lessonTypeIcons: Record<LessonType, React.ReactNode> = {
        youtube: <YoutubeIcon />,
        video: <VideoIcon />,
        audio: <AudioIcon />,
        image: <ImageIcon />,
    };

    return (
        <>
            <div className="max-w-4xl mx-auto bg-base-200 p-8 rounded-lg shadow-2xl border border-base-300 animate-fade-in pb-24">
                <h1 className="text-3xl font-bold text-white mb-6">Publicar Novo Curso</h1>
                <form id="course-upload-form" onSubmit={handleSubmit} className="space-y-8">
                    {/* Course Details */}
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="title" className="block text-sm font-medium text-text-muted mb-2">Título do Curso</label>
                            <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} placeholder="Ex: Mestre em Culinária Italiana" className="w-full bg-base-300 text-white p-3 rounded-md border-2 border-transparent focus:border-brand-primary focus:outline-none"/>
                        </div>
                        <div>
                            <label htmlFor="description" className="block text-sm font-medium text-text-muted mb-2">Descrição do Curso</label>
                            <textarea id="description" value={description} onChange={e => setDescription(e.target.value)} rows={4} placeholder="Descreva o que os alunos aprenderão neste curso." className="w-full bg-base-300 text-white p-3 rounded-md border-2 border-transparent focus:border-brand-primary focus:outline-none"></textarea>
                        </div>
                        <div>
                            <label htmlFor="thumbnail" className="block text-sm font-medium text-text-muted mb-2">Imagem de Capa</label>
                            <div className="mt-2 flex items-center gap-x-4">
                                {thumbnailPreview ? (
                                    <img src={thumbnailPreview} alt="Preview" className="h-24 w-36 object-cover rounded-md" />
                                ) : (
                                    <div className="h-24 w-36 bg-base-300 rounded-md flex items-center justify-center text-text-muted text-sm">Preview</div>
                                )}
                                <input id="thumbnail" type="file" onChange={handleThumbnailChange} accept="image/*" className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-brand-secondary file:text-white hover:file:bg-indigo-500"/>
                            </div>
                        </div>
                    </div>

                    {/* Modules & Lessons */}
                    <div className="space-y-6">
                        <h2 className="text-xl font-semibold text-white">Módulos do Curso</h2>
                        {modules.map((mod, modIndex) => (
                            <div key={mod.id} className="bg-base-300 p-4 rounded-lg border border-base-100/50">
                                <div className="flex items-center justify-between mb-4">
                                    <input type="text" value={mod.title} onChange={e => handleModuleChange(mod.id, e.target.value)} placeholder={`Módulo ${modIndex + 1}: Título do Módulo`} className="flex-grow bg-base-100 text-white p-2 rounded-md border-2 border-transparent focus:border-brand-primary focus:outline-none font-semibold"/>
                                    <button type="button" onClick={() => removeModule(mod.id)} className="ml-4 p-2 text-red-400 hover:bg-red-500/20 rounded-full"><TrashIcon /></button>
                                </div>
                                {/* Lessons */}
                                <div className="space-y-3 pl-4 border-l-2 border-base-100">
                                    {mod.lessons.map((lesson) => (
                                        <div key={lesson.id} className="p-2 bg-base-100/50 rounded-lg">
                                          <div className="flex items-center gap-2 mb-2">
                                              <span className="text-text-muted">{lessonTypeIcons[lesson.type]}</span>
                                              <input type="text" value={lesson.title} onChange={e => handleLessonChange(mod.id, lesson.id, 'title', e.target.value)} placeholder="Título da Aula" className="flex-grow bg-base-300 text-white p-2 rounded-md border-2 border-transparent focus:border-brand-secondary/50 focus:outline-none"/>
                                              <button type="button" onClick={() => removeLesson(mod.id, lesson.id)} className="p-1 text-red-400 hover:bg-red-500/20 rounded-full"><TrashIcon /></button>
                                          </div>
                                          <LessonInput lesson={lesson} modId={mod.id} />
                                        </div>
                                    ))}
                                    <div className="flex items-center gap-2 pt-2 flex-wrap">
                                        <span className="text-sm text-text-muted mr-2">Adicionar Aula:</span>
                                        <button type="button" onClick={() => addLesson(mod.id, 'youtube')} className="flex items-center text-sm font-semibold text-red-400 hover:text-red-300 transition-colors p-2 bg-base-100 rounded-md"> <YoutubeIcon /> <span className="ml-2">YouTube</span></button>
                                        <button type="button" onClick={() => addLesson(mod.id, 'video')} className="flex items-center text-sm font-semibold text-orange-400 hover:text-orange-300 transition-colors p-2 bg-base-100 rounded-md"> <VideoIcon /> <span className="ml-2">Vídeo</span></button>
                                        <button type="button" onClick={() => addLesson(mod.id, 'audio')} className="flex items-center text-sm font-semibold text-sky-400 hover:text-sky-300 transition-colors p-2 bg-base-100 rounded-md"> <AudioIcon /> <span className="ml-2">Áudio</span></button>
                                        <button type="button" onClick={() => addLesson(mod.id, 'image')} className="flex items-center text-sm font-semibold text-green-400 hover:text-green-300 transition-colors p-2 bg-base-100 rounded-md"> <ImageIcon /> <span className="ml-2">Imagem</span></button>
                                    </div>
                                </div>
                            </div>
                        ))}
                        <button type="button" onClick={addModule} className="flex items-center justify-center w-full p-3 border-2 border-dashed border-base-300 rounded-lg text-text-muted hover:bg-base-300 hover:text-white transition-colors">
                            <AddIcon /> Adicionar Módulo
                        </button>
                    </div>
                </form>
            </div>
            
            {/* Sticky Footer for Actions */}
            <div className="fixed bottom-0 left-0 w-full bg-base-200/80 backdrop-blur-lg border-t border-base-300 z-10">
                <div className="max-w-4xl mx-auto px-8 py-3 flex justify-between items-center">
                    <div className="flex-grow pr-4">
                        {error && <p className="text-red-400 text-sm font-semibold">{error}</p>}
                    </div>
                    <button 
                        type="submit" 
                        form="course-upload-form"
                        className="bg-brand-primary hover:bg-teal-500 text-white font-bold py-3 px-6 rounded-lg transition-transform duration-300 transform hover:scale-105 whitespace-nowrap"
                    >
                        Salvar e Publicar
                    </button>
                </div>
            </div>
        </>
    );
};
